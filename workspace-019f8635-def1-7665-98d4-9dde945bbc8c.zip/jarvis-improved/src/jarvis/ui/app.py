"""
Main application window — CustomTkinter dark theme.

Provides: chat panel, settings, and status indicators.
"""

from __future__ import annotations

import logging
import queue

import customtkinter as ctk

from jarvis.config import settings
from jarvis.ui.theme import THEME

logger = logging.getLogger(__name__)

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")


class JarvisApp:
    """Main JARVIS GUI application."""

    def __init__(self) -> None:
        self.root = ctk.CTk()
        self.root.title("JARVIS v2")
        self.root.geometry("1000x650")
        self.root.configure(fg_color=THEME["bg_primary"])
        self.root.minsize(800, 500)

        self._msg_queue: queue.Queue[tuple[str, str]] = queue.Queue()

        self._build_ui()

    def _build_ui(self) -> None:
        # Sidebar
        sidebar = ctk.CTkFrame(self.root, width=200, fg_color=THEME["bg_secondary"], corner_radius=0)
        sidebar.grid(row=0, column=0, sticky="nsew")
        sidebar.grid_propagate(False)

        ctk.CTkLabel(sidebar, text="JARVIS", font=("Segoe UI", 22, "bold"),
                     text_color=THEME["accent"]).pack(pady=(20, 5))
        ctk.CTkLabel(sidebar, text="AI Assistant", font=("Segoe UI", 11),
                     text_color=THEME["text_muted"]).pack(pady=(0, 10))

        ctk.CTkFrame(sidebar, height=1, fg_color=THEME["border"]).pack(fill="x", padx=15, pady=5)

        for label in ["Chat", "History", "Settings"]:
            btn = ctk.CTkButton(
                sidebar, text=label, fg_color="transparent",
                text_color=THEME["text_primary"], hover_color=THEME["bg_tertiary"],
                anchor="w",
            )
            btn.pack(fill="x", padx=10, pady=2)

        # Status at bottom of sidebar
        status_frame = ctk.CTkFrame(sidebar, fg_color="transparent")
        status_frame.pack(fill="x", padx=15, pady=10, side="bottom")
        self.status_label = ctk.CTkLabel(
            status_frame, text="● Ready", font=("Segoe UI", 11),
            text_color=THEME["success"],
        )
        self.status_label.pack()
        ctk.CTkLabel(
            status_frame, text=f"Hello, {settings.OWNER_NAME}",
            font=("Segoe UI", 10), text_color=THEME["text_muted"],
        ).pack(pady=(5, 0))

        # Main content
        main = ctk.CTkFrame(self.root, fg_color=THEME["bg_primary"])
        main.grid(row=0, column=1, sticky="nsew", padx=0, pady=0)
        self.root.grid_columnconfigure(1, weight=1)
        self.root.grid_rowconfigure(0, weight=1)

        # Chat display
        self.chat_display = ctk.CTkTextbox(
            main, fg_color=THEME["bg_secondary"], text_color=THEME["text_primary"],
            font=("Consolas", 13), wrap="word", corner_radius=8,
        )
        self.chat_display.pack(fill="both", expand=True, padx=15, pady=(15, 5))
        self.chat_display.insert("end", "JARVIS v2 — Ready.\nType a message or speak.\n\n")
        self.chat_display.configure(state="disabled")

        # Input row
        input_frame = ctk.CTkFrame(main, fg_color="transparent")
        input_frame.pack(fill="x", padx=15, pady=(5, 15))

        self.input_box = ctk.CTkTextbox(input_frame, height=50, fg_color=THEME["bg_tertiary"],
                                         text_color=THEME["text_primary"], font=("Consolas", 13))
        self.input_box.pack(side="left", fill="x", expand=True, padx=(0, 10))
        self.input_box.bind("<Return>", self._on_enter)

        send_btn = ctk.CTkButton(input_frame, text="Send", width=80, command=self._on_send,
                                  fg_color=THEME["accent"], hover_color=THEME["accent_hover"])
        send_btn.pack(side="right")

    def _on_enter(self, event: object) -> str | None:
        if not hasattr(event, "state") or not (event.state & 0x1):  # no Shift
            self._on_send()
            return "break"
        return None

    def _on_send(self) -> None:
        text = self.input_box.get("1.0", "end").strip()
        if not text:
            return
        self.input_box.delete("1.0", "end")
        self._append_chat("You", text)
        self._msg_queue.put(("user", text))

    def _append_chat(self, speaker: str, text: str) -> None:
        self.chat_display.configure(state="normal")
        self.chat_display.insert("end", f"{speaker}: {text}\n\n")
        self.chat_display.see("end")
        self.chat_display.configure(state="disabled")

    def append_response(self, text: str) -> None:
        self._append_chat("JARVIS", text)

    def set_status(self, text: str, color: str = "") -> None:
        self.status_label.configure(text=f"● {text}")
        if color:
            self.status_label.configure(text_color=color)

    def get_message_queue(self) -> queue.Queue:
        return self._msg_queue

    def run(self) -> None:
        self.root.mainloop()

    def stop(self) -> None:
        self.root.quit()
