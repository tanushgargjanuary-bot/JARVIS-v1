"""
JARVIS — AI Voice Assistant
============================
A lightweight, cross-platform AI assistant powered by Groq API (Llama 3).

Originally forked from https://github.com/talibmakhdum/JARVIS-v0
"""

__version__ = "2.0.0"
__all__ = ["__version__"]
