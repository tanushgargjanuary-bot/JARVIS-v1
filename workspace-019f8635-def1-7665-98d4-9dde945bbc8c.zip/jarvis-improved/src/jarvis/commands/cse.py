"""
CSE student tools — code explanations, debugging, complexity, interview prep.

These commands delegate to the AI brain for detailed answers.
"""

from __future__ import annotations

from jarvis.brain import brain
from jarvis.commands import register


@register(r"^explain (?P<topic>.+)", category="cse", description="Explain a CS concept")
def explain_concept(topic: str) -> str:
    """Explain a CS concept in simple terms."""
    return brain.ask(
        f"Explain '{topic}' in simple terms suitable for a computer science student. "
        "Keep the explanation to 3-4 sentences."
    )


@register(r"^debug (?:my )?code", category="cse", description="Interactive debugging helper")
def debug_assistant() -> str:
    """Return a prompt for the debugging flow."""
    return "Please paste your code and the error message. I'll help you debug it."


@register(
    r"^(?:analyze |what(?:'s| is) the )?complexity (?:of )?(?P<algorithm>.+)",
    category="cse",
    description="Time/space complexity",
)
def code_complexity(algorithm: str) -> str:
    """Analyze time and space complexity of an algorithm."""
    return brain.ask(
        f"Analyze the time and space complexity of '{algorithm}'. "
        "Give Big-O for best, average, and worst case. Be concise."
    )


@register(r"^generate code (?:for )?(?P<description>.+)", category="cse", description="Generate code snippet")
def generate_code(description: str) -> str:
    """Generate a code snippet."""
    return brain.ask(
        f"Write clean, well-commented Python code for the following: {description}. "
        "Include docstrings and type hints."
    )


@register(r"^interview (?:prep|prepare) (?:for |on )?(?P<topic>.+)", category="cse", description="Interview prep")
def interview_prep(topic: str) -> str:
    """Generate interview preparation questions."""
    return brain.ask(
        f"Give me 5 common interview questions about '{topic}' for a software engineering role. "
        "For each question, provide a brief model answer."
    )


@register(r"^explain (?:this )?error:?\s*(?P<error>.+)", category="cse", description="Explain an error message")
def explain_error(error: str) -> str:
    """Explain an error message."""
    return brain.ask(
        f"Explain this error message in simple terms and suggest how to fix it: {error}"
    )
