"""
Notes commands — create, read, list voice-dictated notes.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from jarvis.commands import register
from jarvis.config import settings


def _notes_dir() -> Path:
    return settings.NOTES_DIR


@register(r"^create note(?:s)?", category="notes", description="Create a note (voice dictation)")
def create_note() -> str:
    """Create a new note. In voice mode the caller should pass recognised text."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filepath = _notes_dir() / f"note_{timestamp}.txt"
    # If called from voice, the main loop should supply dictation text.
    # Standalone call creates an empty placeholder.
    filepath.write_text("", encoding="utf-8")
    return f"Note created: {filepath.name}. Say your note or type it."


def save_note(text: str) -> str:
    """Save *text* as a new note file. Returns the filename."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"note_{timestamp}.txt"
    filepath = _notes_dir() / filename
    filepath.write_text(text, encoding="utf-8")
    return f"Note saved: {filename}"


@register(r"^read (?:my )?(?:last |latest )?note", category="notes", description="Read last note")
def read_last_note() -> str:
    """Read the most recent note aloud."""
    notes = sorted(_notes_dir().glob("note_*.txt"), key=lambda p: p.stat().st_mtime)
    if not notes:
        return "You don't have any notes yet."
    content = notes[-1].read_text(encoding="utf-8").strip()
    if not content:
        return f"The latest note ({notes[-1].name}) is empty."
    return f"From {notes[-1].name}: {content}"


@register(r"^list (?:my )?notes", category="notes", description="List all notes")
def list_notes() -> str:
    """List all saved notes."""
    notes = sorted(_notes_dir().glob("note_*.txt"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not notes:
        return "No notes found."
    names = [n.name for n in notes[:10]]
    return f"You have {len(notes)} note(s). Latest: {', '.join(names)}"
