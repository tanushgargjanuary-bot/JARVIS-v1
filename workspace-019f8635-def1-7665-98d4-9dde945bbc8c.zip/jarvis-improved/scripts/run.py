#!/usr/bin/env python3
"""Quick launcher — ``python scripts/run.py``"""

from jarvis.__main__ import main

if __name__ == "__main__":
    main()
