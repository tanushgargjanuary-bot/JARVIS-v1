"""
Web commands — open websites, search engines, weather.
"""

from __future__ import annotations

import webbrowser

from jarvis.commands import register
from jarvis.config import settings

# ---------------------------------------------------------------------------
# Website shortcuts
# ---------------------------------------------------------------------------

WEBSITES: dict[str, str] = {
    "google": "https://www.google.com",
    "youtube": "https://www.youtube.com",
    "github": "https://www.github.com",
    "stackoverflow": "https://stackoverflow.com",
    "reddit": "https://www.reddit.com",
    "twitter": "https://twitter.com",
    "x": "https://x.com",
    "linkedin": "https://www.linkedin.com",
    "gmail": "https://mail.google.com",
    "chatgpt": "https://chat.openai.com",
    "leetcode": "https://leetcode.com",
    "geeksforgeeks": "https://www.geeksforgeeks.org",
    "wikipedia": "https://www.wikipedia.org",
    "amazon": "https://www.amazon.com",
    "netflix": "https://www.netflix.com",
    "spotify": "https://open.spotify.com",
    "hackerrank": "https://www.hackerrank.com",
    "codeforces": "https://codeforces.com",
}

SEARCH_ENGINES: dict[str, str] = {
    "google": "https://www.google.com/search?q={}",
    "youtube": "https://www.youtube.com/results?search_query={}",
    "github": "https://github.com/search?q={}",
    "stackoverflow": "https://stackoverflow.com/search?q={}",
    "bing": "https://www.bing.com/search?q={}",
    "duckduckgo": "https://duckduckgo.com/?q={}",
}


# ---------------------------------------------------------------------------
# Go to website
# ---------------------------------------------------------------------------

@register(r"^(?:go to|open) (?P<site>.+)", category="web", description="Open a website")
def open_website(site: str) -> str:
    """Open a website by name or URL."""
    site_lower = site.lower().strip()

    # Direct URL
    if site_lower.startswith("http://") or site_lower.startswith("https://"):
        webbrowser.open(site_lower)
        return f"Opening {site_lower}"

    # Known website
    if site_lower in WEBSITES:
        webbrowser.open(WEBSITES[site_lower])
        return f"Opening {site_lower}."

    # Partial match
    for name, url in WEBSITES.items():
        if name in site_lower or site_lower in name:
            webbrowser.open(url)
            return f"Opening {name}."

    # Assume it's a domain
    if "." in site_lower:
        url = f"https://{site_lower}"
        webbrowser.open(url)
        return f"Opening {url}"

    return f"I don't know the website for '{site}'."


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------

@register(r"^search (?:on )?(?P<engine>\w+)(?: for)? (?P<query>.+)", category="web", description="Search the web")
def search_engine(engine: str, query: str) -> str:
    """Search a specific engine."""
    engine_lower = engine.lower().strip()
    if engine_lower in SEARCH_ENGINES:
        url = SEARCH_ENGINES[engine_lower].format(query)
        webbrowser.open(url)
        return f"Searching {engine_lower} for: {query}"
    # Default to Google
    url = SEARCH_ENGINES["google"].format(f"{engine} {query}")
    webbrowser.open(url)
    return f"Searching Google for: {engine} {query}"


@register(r"^search (?:for )?(?P<query>.+)", category="web", description="Google search")
def search_google(query: str) -> str:
    """Search Google."""
    url = SEARCH_ENGINES["google"].format(query)
    webbrowser.open(url)
    return f"Searching Google for: {query}"


@register(r"^search youtube for (?P<query>.+)", category="web", description="Search YouTube")
def search_youtube(query: str) -> str:
    """Search YouTube."""
    url = SEARCH_ENGINES["youtube"].format(query)
    webbrowser.open(url)
    return f"Searching YouTube for: {query}"


# ---------------------------------------------------------------------------
# Weather
# ---------------------------------------------------------------------------

@register(r"^(?:what(?:'s| is) the )?weather(?: in (?P<city>.+))?", category="web", description="Get weather")
def get_weather(city: str = "") -> str:
    """Get current weather via wttr.in."""
    import requests

    city = city.strip() or settings.CITY
    try:
        resp = requests.get(
            f"https://wttr.in/{city}?format=%l:+%C+%t+%h+%w",
            timeout=10,
        )
        if resp.status_code == 200:
            return resp.text.strip()
        return f"Could not fetch weather for {city}."
    except Exception as exc:
        return f"Weather error: {exc}"
