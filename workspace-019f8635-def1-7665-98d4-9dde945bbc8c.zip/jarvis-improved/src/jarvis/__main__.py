"""
JARVIS entry point — ``python -m jarvis`` or ``jarvis``.

Starts the voice loop (if mic available) and/or the GUI (if customtkinter available),
or falls back to terminal mode.
"""

from __future__ import annotations

import logging
import sys
import threading

from jarvis.brain import brain
from jarvis.commands import match_command
from jarvis.config import Settings, settings
from jarvis.storage import chat_db
from jarvis.tools import ToolExecutor
from jarvis.voice import listener, speak

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------

def _setup_logging() -> None:
    log_file = settings.LOGS_DIR / "jarvis.log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(str(log_file), encoding="utf-8"),
        ],
    )


# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------

def _process_input(text: str, executor: ToolExecutor, conv_id: str) -> str:
    """Route user input through commands → brain → response."""
    # 1. Try local command matching
    result = match_command(text)
    if result is not None:
        cmd, groups = result
        response = cmd.handler(**groups)
        chat_db.add_message(conv_id, "user", text)
        chat_db.add_message(conv_id, "assistant", response)
        return response

    # 2. Fall through to AI brain (with tool calling if enabled)
    if settings.AGENT_TOOLS_ENABLED and brain.online:
        result_dict = brain.ask_with_tools(text, executor.get_schemas(), executor)
        response = result_dict["response"]
    elif brain.online:
        response = brain.ask(text)
    else:
        response = "I'm not sure how to help with that. (Brain is offline.)"

    chat_db.add_message(conv_id, "user", text)
    chat_db.add_message(conv_id, "assistant", response)
    return response


def _terminal_loop(executor: ToolExecutor, conv_id: str) -> None:
    """Simple REPL for terminal-only mode."""
    print(f"\n{'='*50}")
    print("  JARVIS v2 — Terminal Mode")
    print("  Type 'quit' to exit")
    print(f"{'='*50}\n")

    while True:
        try:
            user_input = input(f"[{settings.OWNER_NAME}] > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not user_input:
            continue
        if user_input.lower() in ("quit", "exit", "bye"):
            speak("Goodbye!")
            break

        response = _process_input(user_input, executor, conv_id)
        print(f"\n[JARVIS] {response}\n")
        speak(response)


def _voice_loop(executor: ToolExecutor, conv_id: str) -> None:
    """Continuous wake-word + command loop."""
    if not listener.available:
        logger.error("Microphone not available. Falling back to terminal mode.")
        _terminal_loop(executor, conv_id)
        return

    print(f"\n[Voice Mode] Listening for wake word: '{settings.WAKE_WORD}'\n")
    speak(f"JARVIS online. Say '{settings.WAKE_WORD}' to activate.")

    while True:
        # Listen for wake word
        heard = listener.listen(timeout=3.0)
        if heard is None:
            continue
        if settings.WAKE_WORD not in heard.lower():
            continue

        # Wake word detected
        speak("Yes?")
        command = listener.listen(timeout=6.0)
        if not command:
            speak("I didn't catch that.")
            continue

        response = _process_input(command, executor, conv_id)
        speak(response)


def _gui_loop(executor: ToolExecutor, conv_id: str) -> None:
    """GUI mode — CustomTkinter window + background processing."""
    try:
        from jarvis.ui import JarvisApp
    except ImportError:
        logger.warning("CustomTkinter not available. Falling back to terminal.")
        _terminal_loop(executor, conv_id)
        return

    app = JarvisApp()
    msg_queue = app.get_message_queue()

    def _worker() -> None:
        while True:
            try:
                role, text = msg_queue.get(timeout=0.5)
                response = _process_input(text, executor, conv_id)
                app.append_response(response)
                speak(response)
            except Exception:
                pass

    threading.Thread(target=_worker, daemon=True).start()
    app.run()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    _setup_logging()

    # Validate config
    warnings = Settings.validate()
    for w in warnings:
        print(f"[WARNING] {w}")

    executor = ToolExecutor()
    conv_id = chat_db.create_conversation("Terminal Session")

    logger.info("JARVIS v%s starting.", "2.0.0")

    # Decide mode
    if "--terminal" in sys.argv or "--text" in sys.argv:
        _terminal_loop(executor, conv_id)
    elif "--voice" in sys.argv:
        _voice_loop(executor, conv_id)
    elif "--gui" in sys.argv:
        _gui_loop(executor, conv_id)
    else:
        # Auto-detect: GUI if available, else terminal
        try:
            from jarvis.ui import is_ui_available
            if is_ui_available():
                _gui_loop(executor, conv_id)
            else:
                _terminal_loop(executor, conv_id)
        except ImportError:
            _terminal_loop(executor, conv_id)


if __name__ == "__main__":
    main()
