"""
AI brain — Groq API interaction.

Handles chat completions with context windowing, system prompt,
and optional function / tool calling.
"""

from __future__ import annotations

import json
import logging
from collections import deque
from typing import Any

from jarvis.config import settings

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """\
You are JARVIS, a helpful AI voice assistant. You are running on the user's \
desktop computer and can help with tasks, answer questions, and have \
conversations.

Guidelines:
- Be concise and helpful. Voice responses should be short (1–3 sentences).
- Address the user as "{owner}" unless they ask otherwise.
- You are not a replacement for a terminal or shell — suggest the user run \
  commands themselves when appropriate.
- If you don't know something, say so honestly.
""".replace("{owner}", settings.OWNER_NAME)

# ---------------------------------------------------------------------------
# Conversation memory (in-process)
# ---------------------------------------------------------------------------

class Memory:
    """Sliding-window conversation memory."""

    def __init__(self, max_size: int = 30) -> None:
        self._buffer: deque[dict[str, str]] = deque(maxlen=max_size)

    def add(self, role: str, content: str) -> None:
        self._buffer.append({"role": role, "content": content})

    def get_messages(self) -> list[dict[str, str]]:
        return list(self._buffer)

    def clear(self) -> None:
        self._buffer.clear()

    def __len__(self) -> int:
        return len(self._buffer)


memory = Memory(settings.MAX_MEMORY)

# ---------------------------------------------------------------------------
# Brain
# ---------------------------------------------------------------------------

class Brain:
    """Groq LLM wrapper with conversation memory and optional tool calling."""

    def __init__(self) -> None:
        self._client = None
        self._init_client()

    def _init_client(self) -> None:
        if not settings.GROQ_API_KEY or settings.GROQ_API_KEY == "your_groq_key_here":
            logger.warning("GROQ_API_KEY not set — Brain will be offline.")
            return
        try:
            from groq import Groq  # type: ignore[import-untyped]
            self._client = Groq(api_key=settings.GROQ_API_KEY)
            logger.info("Groq client initialised (model=%s).", settings.AI_MODEL)
        except Exception as exc:
            logger.error("Failed to initialise Groq client: %s", exc)

    @property
    def online(self) -> bool:
        return self._client is not None

    # -- simple chat --
    def ask(self, user_message: str, extra_messages: list[dict[str, str]] | None = None) -> str:
        """Send *user_message* with conversation memory and return the reply."""
        if not self.online:
            return "[Brain offline] Set GROQ_API_KEY in your .env file."

        messages: list[dict[str, str]] = [{"role": "system", "content": SYSTEM_PROMPT}]
        messages.extend(memory.get_messages())
        if extra_messages:
            messages.extend(extra_messages)
        messages.append({"role": "user", "content": user_message})

        try:
            response = self._client.chat.completions.create(
                model=settings.AI_MODEL,
                messages=messages,
                max_tokens=settings.MAX_TOKENS,
                temperature=settings.TEMPERATURE,
            )
            reply = response.choices[0].message.content or ""
            # update memory
            memory.add("user", user_message)
            memory.add("assistant", reply)
            return reply
        except Exception as exc:
            logger.error("Groq API error: %s", exc)
            return f"[Error] {exc}"

    # -- tool / function calling --
    def ask_with_tools(
        self,
        user_message: str,
        tools: list[dict[str, Any]],
        tool_executor: Any,
    ) -> dict[str, Any]:
        """Chat with tool calling. Returns {"response": str, "tool_calls": list}."""
        if not self.online:
            return {"response": "[Brain offline]", "tool_calls": []}

        messages: list[dict[str, str]] = [{"role": "system", "content": SYSTEM_PROMPT}]
        messages.extend(memory.get_messages())
        messages.append({"role": "user", "content": user_message})

        tool_calls_log: list[dict] = []
        max_iterations = 5  # safety limit

        for _ in range(max_iterations):
            try:
                response = self._client.chat.completions.create(
                    model=settings.AI_MODEL,
                    messages=messages,
                    tools=tools,
                    tool_choice="auto",
                    max_tokens=settings.MAX_TOKENS,
                    temperature=settings.TEMPERATURE,
                )
            except Exception as exc:
                logger.error("Groq API error: %s", exc)
                return {"response": f"[Error] {exc}", "tool_calls": tool_calls_log}

            message = response.choices[0].message
            messages.append(message.model_dump())

            if message.tool_calls:
                for tc in message.tool_calls:
                    try:
                        arguments = json.loads(tc.function.arguments)
                    except json.JSONDecodeError:
                        arguments = {}

                    result = tool_executor.execute(tc.function.name, arguments)
                    tool_calls_log.append({
                        "tool": tc.function.name,
                        "args": arguments,
                        "result_preview": result[:300],
                    })
                    messages.append({
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": result,
                    })
            else:
                reply = message.content or "I processed your request."
                memory.add("user", user_message)
                memory.add("assistant", reply)
                return {"response": reply, "tool_calls": tool_calls_log}

        return {
            "response": "I reached the maximum number of tool iterations.",
            "tool_calls": tool_calls_log,
        }


brain = Brain()
