@echo off
REM JARVIS v2 — Windows installer
echo === JARVIS v2 — Setup ===

REM Create venv if it doesn't exist
if not exist ".venv" (
    echo → Creating virtual environment...
    python -m venv .venv
)

call .venv\Scripts\activate.bat

echo → Installing JARVIS (core)...
pip install -e .

echo.
echo Optional: install extra features
echo   pip install -e ".[voice]"   REM microphone + TTS
echo   pip install -e ".[gui]"     REM volume, brightness, screenshots
echo   pip install -e ".[ui]"      REM dark-themed GUI
echo   pip install -e ".[rag]"     REM document Q&amp;A
echo   pip install -e ".[all]"     REM everything
echo.

REM Create .env if missing
if not exist ".env" (
    echo → Creating .env from template...
    copy .env.example .env
    echo   WARNING: Edit .env and add your GROQ_API_KEY
)

echo.
echo === Done! Run JARVIS with: jarvis ===
pause
