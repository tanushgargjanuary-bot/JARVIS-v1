#!/usr/bin/env bash
# JARVIS installer — Linux / macOS
set -e

echo "=== JARVIS v2 — Setup ==="

# Create venv if it doesn't exist
if [ ! -d ".venv" ]; then
    echo "→ Creating virtual environment..."
    python3 -m venv .venv
fi

source .venv/bin/activate

echo "→ Installing JARVIS (core)..."
pip install -e "."

echo ""
echo "Optional: install extra features"
echo "  pip install -e '.[voice]'   # microphone + TTS"
echo "  pip install -e '.[gui]'     # volume, brightness, screenshots"
echo "  pip install -e '.[ui]'      # dark-themed GUI"
echo "  pip install -e '.[rag]'     # document Q&A"
echo "  pip install -e '.[all]'     # everything"
echo ""

# Create .env if missing
if [ ! -f ".env" ]; then
    echo "→ Creating .env from template..."
    cp .env.example .env
    echo "  ⚠  Edit .env and add your GROQ_API_KEY"
fi

echo ""
echo "=== Done! Run JARVIS with: jarvis ==="
