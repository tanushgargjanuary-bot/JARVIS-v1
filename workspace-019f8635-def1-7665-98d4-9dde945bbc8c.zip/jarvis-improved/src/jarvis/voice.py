"""
Voice engine — text-to-speech and speech-to-text.

Gracefully degrades when audio hardware is missing:
- TTS falls back to printing to stdout
- STT is disabled and the caller gets None
"""

from __future__ import annotations

import logging
import threading

from jarvis.config import settings

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# TTS
# ---------------------------------------------------------------------------

class VoiceEngine:
    """Cross-platform TTS wrapper.

    - Windows/macOS: pyttsx3 (SAPI5 / NSSpeechSynthesizer)
    - Linux: pyttsx3 (espeak) if available, else print
    - Headless / CI: prints to stdout
    """

    def __init__(self) -> None:
        self._engine = None
        self._lock = threading.Lock()
        self._voice_enabled = settings.VOICE_ENABLED
        self._init_engine()

    # -- init --
    def _init_engine(self) -> None:
        try:
            import pyttsx3  # type: ignore[import-untyped]
            self._engine = pyttsx3.init()
            self._engine.setProperty("rate", settings.VOICE_SPEED)
            self._engine.setProperty("volume", 1.0)
            self._pick_voice()
        except Exception as exc:
            logger.warning("TTS engine unavailable (%s) — falling back to stdout.", exc)
            self._engine = None

    def _pick_voice(self) -> None:
        """Select the best available system voice (Windows: Zira > David > …)."""
        if self._engine is None:
            return
        try:
            voices = self._engine.getProperty("voices")
            preferred = ["zira", "david", "hazel", "susan"]
            for pref in preferred:
                for v in voices:
                    if pref in v.name.lower():
                        self._engine.setProperty("voice", v.id)
                        return
        except Exception:
            pass  # use default voice

    # -- public API --
    def speak(self, text: str) -> None:
        """Speak *text* aloud, or print if TTS is unavailable."""
        with self._lock:
            if self._engine is not None:
                try:
                    self._engine.say(text)
                    self._engine.runAndWait()
                    return
                except Exception as exc:
                    logger.warning("TTS speak failed: %s", exc)
            # fallback
            print(f"[JARVIS] {text}")

    @property
    def enabled(self) -> bool:
        return self._voice_enabled

    @enabled.setter
    def enabled(self, value: bool) -> None:
        self._voice_enabled = value


# ---------------------------------------------------------------------------
# STT
# ---------------------------------------------------------------------------

class Listener:
    """Microphone-based speech recognition.

    Returns None when the microphone is unavailable or disabled.
    """

    def __init__(self) -> None:
        self._recognizer = None
        self._mic = None
        self._init_mic()

    def _init_mic(self) -> None:
        if not settings.VOICE_ENABLED:
            return
        try:
            import speech_recognition as sr  # type: ignore[import-untyped]
            self._recognizer = sr.Recognizer()
            self._mic = sr.Microphone()
            # quick sanity check — open and close
            with self._mic as source:
                self._recognizer.adjust_for_ambient_noise(source, duration=0.3)
            logger.info("Microphone initialised successfully.")
        except Exception as exc:
            logger.warning("Microphone unavailable (%s) — voice input disabled.", exc)
            self._recognizer = None
            self._mic = None

    def listen(self, timeout: float = 5.0) -> str | None:
        """Listen for speech and return recognised text, or None."""
        if self._recognizer is None or self._mic is None:
            return None
        try:
            import speech_recognition as sr  # type: ignore[import-untyped]
            with self._mic as source:
                self._recognizer.adjust_for_ambient_noise(source, duration=0.3)
                audio = self._recognizer.listen(source, timeout=timeout)
            text: str = self._recognizer.recognize_google(audio)
            return text.strip()
        except sr.WaitTimeoutError:  # type: ignore[name-defined]
            return None
        except sr.UnknownValueError:  # type: ignore[name-defined]
            return None
        except sr.RequestError as exc:  # type: ignore[name-defined]
            logger.error("Speech recognition service error: %s", exc)
            return None
        except Exception as exc:
            logger.error("Listen error: %s", exc)
            return None

    @property
    def available(self) -> bool:
        return self._recognizer is not None


# ---------------------------------------------------------------------------
# Module-level singletons
# ---------------------------------------------------------------------------
voice = VoiceEngine()
listener = Listener()


def speak(text: str) -> None:
    """Convenience — speak through the global voice engine."""
    voice.speak(text)
