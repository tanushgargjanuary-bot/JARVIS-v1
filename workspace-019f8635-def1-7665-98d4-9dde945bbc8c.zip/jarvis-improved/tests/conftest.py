"""Shared pytest fixtures."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture
def tmp_notes_dir(tmp_path: Path) -> Path:
    """Provide a temporary notes directory."""
    notes = tmp_path / "notes"
    notes.mkdir()
    return notes


@pytest.fixture
def mock_settings(tmp_path: Path):
    """Patch settings to use temporary directories."""
    with patch("jarvis.config.settings") as m:
        m.NOTES_DIR = tmp_path / "notes"
        m.NOTES_DIR.mkdir(exist_ok=True)
        m.MEMORY_DIR = tmp_path / "memory"
        m.MEMORY_DIR.mkdir(exist_ok=True)
        m.SCREENSHOTS_DIR = tmp_path / "screenshots"
        m.SCREENSHOTS_DIR.mkdir(exist_ok=True)
        m.LOGS_DIR = tmp_path / "logs"
        m.LOGS_DIR.mkdir(exist_ok=True)
        m.RAG_DIR = tmp_path / "rag"
        m.RAG_DIR.mkdir(exist_ok=True)
        m.OWNER_NAME = "Tester"
        m.CITY = "TestCity"
        m.WAKE_WORD = "jarvis"
        m.VOICE_ENABLED = False
        m.GROQ_API_KEY = ""
        m.AGENT_TOOLS_ENABLED = False
        m.RAG_ENABLED = False
        yield m
