"""Tests for the RAG engine (chunking and parsing).

These tests exercise the pure-Python logic without requiring
chromadb or sentence-transformers.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest


# ---------------------------------------------------------------------------
# Reproduce the chunking logic here so we don't need heavy imports
# ---------------------------------------------------------------------------

def _chunk_text(text: str, size: int = 512, overlap: int = 128) -> list[str]:
    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    if not text:
        return []
    if len(text) <= size:
        return [text]
    chunks: list[str] = []
    start = 0
    while start < len(text):
        end = min(start + size, len(text))
        if end < len(text):
            for sep in ["\n\n", ". ", "\n", " "]:
                pos = text.rfind(sep, start + size // 2, end)
                if pos > start:
                    end = pos + len(sep)
                    break
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        start = end - overlap
        if start >= end:
            start = end
    return chunks


def _parse_text_file(path: Path) -> str:
    for enc in ("utf-8", "latin-1"):
        try:
            return path.read_text(encoding=enc)
        except UnicodeDecodeError:
            continue
    return ""


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestChunking:
    def test_short_text_single_chunk(self):
        chunks = _chunk_text("Hello world")
        assert len(chunks) == 1
        assert chunks[0] == "Hello world"

    def test_long_text_splits(self):
        text = "A" * 200 + "\n\n" + "B" * 200 + "\n\n" + "C" * 200
        chunks = _chunk_text(text, size=300, overlap=50)
        assert len(chunks) >= 2
        # All text should be covered
        combined = " ".join(chunks)
        assert "A" in combined
        assert "B" in combined
        assert "C" in combined

    def test_empty_text(self):
        chunks = _chunk_text("")
        assert chunks == []

    def test_paragraph_boundary(self):
        text = ("First paragraph. " * 20) + "\n\n" + ("Second paragraph. " * 20)
        chunks = _chunk_text(text, size=200, overlap=50)
        assert len(chunks) >= 2

    def test_overlap_preserves_continuity(self):
        text = "word " * 300  # 1500 chars
        chunks = _chunk_text(text, size=200, overlap=80)
        # Adjacent chunks should share some text
        for i in range(len(chunks) - 1):
            # The end of chunk i should overlap with start of chunk i+1
            end_words = set(chunks[i].split()[-5:])
            start_words = set(chunks[i + 1].split()[:5])
            # At least some overlap expected
            assert end_words & start_words or len(chunks) <= 2


class TestParsing:
    def test_parse_text_file(self, tmp_path: Path):
        f = tmp_path / "test.txt"
        f.write_text("Hello from a test file.", encoding="utf-8")
        text = _parse_text_file(f)
        assert "Hello" in text

    def test_parse_python_file(self, tmp_path: Path):
        f = tmp_path / "code.py"
        f.write_text("def hello():\n    print('hi')\n", encoding="utf-8")
        text = _parse_text_file(f)
        assert "hello" in text

    def test_parse_unicode(self, tmp_path: Path):
        f = tmp_path / "unicode.txt"
        f.write_text("Héllo wörld — 日本語", encoding="utf-8")
        text = _parse_text_file(f)
        assert "Héllo" in text
