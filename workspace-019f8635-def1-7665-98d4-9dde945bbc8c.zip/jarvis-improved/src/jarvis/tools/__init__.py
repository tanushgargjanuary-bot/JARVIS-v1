"""
Tool execution engine — runs registered agent tools.

Each tool is a callable that receives keyword arguments and returns a string.
"""

from __future__ import annotations

import logging
from typing import Any, Callable

logger = logging.getLogger(__name__)

# Registry: tool_name -> {schema, handler}
_TOOL_REGISTRY: dict[str, dict[str, Any]] = {}


def tool(name: str, description: str, parameters: dict[str, Any]) -> Callable:
    """Decorator to register a tool.

    Usage::

        @tool("web_search", "Search the web", {"query": {"type": "string"}})
        def web_search(query: str) -> str:
            ...
    """
    def decorator(func: Callable) -> Callable:
        _TOOL_REGISTRY[name] = {
            "schema": {
                "type": "function",
                "function": {
                    "name": name,
                    "description": description,
                    "parameters": {
                        "type": "object",
                        "properties": parameters,
                    },
                },
            },
            "handler": func,
        }
        return func
    return decorator


class ToolExecutor:
    """Execute registered tools by name."""

    def execute(self, tool_name: str, arguments: dict[str, Any]) -> str:
        """Execute *tool_name* with *arguments*. Returns result string."""
        entry = _TOOL_REGISTRY.get(tool_name)
        if entry is None:
            return f"Error: unknown tool '{tool_name}'"
        try:
            return entry["handler"](**arguments)
        except Exception as exc:
            logger.error("Tool %s failed: %s", tool_name, exc)
            return f"Tool '{tool_name}' failed: {exc}"

    def get_schemas(self) -> list[dict[str, Any]]:
        """Return all tool schemas for the Groq API."""
        return [entry["schema"] for entry in _TOOL_REGISTRY.values()]


def list_tools() -> list[str]:
    """Return names of all registered tools."""
    return list(_TOOL_REGISTRY.keys())


# Import sub-modules so their @tool decorators fire
from jarvis.tools import (  # noqa: F401, E402
    calculator,
    datetime_tool,
    file_ops,
    system_info,
    web_search,
)
