"""Tests for agent tools."""

from __future__ import annotations

import json

from jarvis.tools import ToolExecutor, list_tools


class TestToolRegistry:
    def test_tools_registered(self):
        names = list_tools()
        assert "web_search" in names
        assert "calculator" in names
        assert "system_info" in names
        assert "datetime_tool" in names
        assert "file_operations" in names

    def test_executor_schemas(self):
        executor = ToolExecutor()
        schemas = executor.get_schemas()
        assert len(schemas) >= 5
        # Each schema should have the right structure
        for schema in schemas:
            assert schema["type"] == "function"
            assert "function" in schema
            assert "name" in schema["function"]


class TestCalculator:
    def test_basic_math(self):
        executor = ToolExecutor()
        result = executor.execute("calculator", {"expression": "2 + 3 * 4"})
        assert "14" in result

    def test_percent(self):
        executor = ToolExecutor()
        result = executor.execute("calculator", {"expression": "15 percent of 3000"})
        assert "450" in result

    def test_unknown_tool(self):
        executor = ToolExecutor()
        result = executor.execute("nonexistent_tool", {})
        assert "Error" in result or "unknown" in result.lower()


class TestDateTimeTool:
    def test_now(self):
        executor = ToolExecutor()
        result = executor.execute("datetime_tool", {"query": "now"})
        assert ":" in result  # contains time

    def test_weekday(self):
        executor = ToolExecutor()
        result = executor.execute("datetime_tool", {"query": "weekday"})
        # Should be a day name
        days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        assert any(d in result for d in days)


class TestSystemInfo:
    def test_basic(self):
        executor = ToolExecutor()
        result = executor.execute("system_info", {"detail": "basic"})
        data = json.loads(result)
        assert "cpu_percent" in data
        assert "ram_percent" in data
