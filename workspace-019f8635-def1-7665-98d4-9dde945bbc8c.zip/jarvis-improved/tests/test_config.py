"""Tests for the configuration module."""

from __future__ import annotations

from unittest.mock import patch

from jarvis.config import Settings, _env, _env_bool, _env_int


class TestEnvHelpers:
    def test_env_default(self):
        assert _env("NONEXISTENT_KEY_12345", "fallback") == "fallback"

    def test_env_bool_default(self):
        assert _env_bool("NONEXISTENT_KEY_12345", False) is False
        assert _env_bool("NONEXISTENT_KEY_12345", True) is True

    def test_env_int_default(self):
        assert _env_int("NONEXISTENT_KEY_12345", 42) == 42

    def test_env_int_bad_value(self):
        with patch.dict("os.environ", {"TEST_BAD_INT": "not_a_number"}):
            assert _env_int("TEST_BAD_INT", 99) == 99


class TestSettings:
    def test_validate_no_api_key(self):
        with patch.object(Settings, "GROQ_API_KEY", ""):
            warnings = Settings.validate()
            assert len(warnings) == 1
            assert "GROQ_API_KEY" in warnings[0]

    def test_validate_with_api_key(self):
        with patch.object(Settings, "GROQ_API_KEY", "gsk_real_key_12345"):
            warnings = Settings.validate()
            assert len(warnings) == 0

    def test_as_dict(self):
        d = Settings.as_dict()
        assert "OWNER_NAME" in d
        assert "CITY" in d
        assert isinstance(d["VOICE_SPEED"], int)
