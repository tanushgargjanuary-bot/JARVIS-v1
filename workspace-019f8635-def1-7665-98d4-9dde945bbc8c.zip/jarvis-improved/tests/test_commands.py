"""Tests for command parsing and handlers."""

from __future__ import annotations

import pytest

from jarvis.commands import match_command, list_commands


class TestCommandRouter:
    def test_registry_populated(self):
        """Commands should auto-register on import."""
        cmds = list_commands()
        assert len(cmds) > 10, "Expected at least 10 registered commands"

    def test_match_joke(self):
        result = match_command("tell me a joke")
        assert result is not None
        cmd, groups = result
        assert "joke" in cmd.category or "fun" in cmd.category

    def test_match_open(self):
        result = match_command("open firefox")
        assert result is not None
        cmd, groups = result
        assert groups.get("name") == "firefox"

    def test_match_time(self):
        result = match_command("what time is it")
        assert result is not None

    def test_match_weather(self):
        result = match_command("weather in London")
        assert result is not None

    def test_match_unknown(self):
        result = match_command("xyzzy foobar 12345")
        assert result is None

    def test_calculate(self):
        result = match_command("calculate 15 percent of 3000")
        assert result is not None
        cmd, groups = result
        response = cmd.handler(**groups)
        assert "450" in response

    def test_flip_coin(self):
        result = match_command("flip a coin")
        assert result is not None
        cmd, groups = result
        response = cmd.handler(**groups)
        assert "heads" in response.lower() or "tails" in response.lower()

    def test_get_time(self):
        result = match_command("what time is it")
        assert result is not None
        cmd, groups = result
        response = cmd.handler(**groups)
        assert ":" in response  # should contain time

    def test_get_date(self):
        result = match_command("what is the date")
        assert result is not None
        cmd, groups = result
        response = cmd.handler(**groups)
        assert "20" in response  # contains year
