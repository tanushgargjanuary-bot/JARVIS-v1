"""Tests for the chat database."""

from __future__ import annotations

import pytest
from pathlib import Path

from jarvis.storage.chat_db import ChatDatabase


class TestChatDatabase:
    @pytest.fixture
    def db(self, tmp_path: Path) -> ChatDatabase:
        return ChatDatabase(db_path=tmp_path / "test.db")

    def test_create_conversation(self, db: ChatDatabase):
        cid = db.create_conversation("Test Chat")
        assert cid
        convs = db.list_conversations()
        assert len(convs) == 1
        assert convs[0]["title"] == "Test Chat"

    def test_add_and_get_messages(self, db: ChatDatabase):
        cid = db.create_conversation("Chat")
        db.add_message(cid, "user", "Hello")
        db.add_message(cid, "assistant", "Hi there!")
        msgs = db.get_messages(cid)
        assert len(msgs) == 2
        assert msgs[0]["role"] == "user"
        assert msgs[1]["content"] == "Hi there!"

    def test_ai_context(self, db: ChatDatabase):
        cid = db.create_conversation("Chat")
        db.add_message(cid, "user", "Q1")
        db.add_message(cid, "assistant", "A1")
        db.add_message(cid, "user", "Q2")
        ctx = db.get_ai_context(cid, limit=10)
        assert len(ctx) == 3
        assert ctx[0] == {"role": "user", "content": "Q1"}

    def test_search_messages(self, db: ChatDatabase):
        cid = db.create_conversation("Chat")
        db.add_message(cid, "user", "The quick brown fox")
        db.add_message(cid, "user", "A lazy dog")
        results = db.search_messages("fox")
        assert len(results) >= 1
        assert "fox" in results[0]["content"]

    def test_delete_conversation(self, db: ChatDatabase):
        cid = db.create_conversation("ToDelete")
        db.add_message(cid, "user", "msg")
        db.delete_conversation(cid)
        assert len(db.list_conversations()) == 0

    def test_pin_conversation(self, db: ChatDatabase):
        cid = db.create_conversation("Pinned")
        db.pin_conversation(cid, True)
        convs = db.list_conversations()
        assert convs[0]["is_pinned"] == 1

    def test_stats(self, db: ChatDatabase):
        cid = db.create_conversation("Stats")
        db.add_message(cid, "user", "hello")
        db.add_message(cid, "assistant", "world")
        stats = db.get_stats()
        assert stats["conversations"] == 1
        assert stats["messages"] == 2
