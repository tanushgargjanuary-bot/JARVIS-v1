"""
RAG engine — parse documents, chunk, embed, and search with ChromaDB.

Dependencies are optional: chromadb, sentence-transformers, PyPDF2, python-docx.
If missing, the engine reports unavailable and gracefully degrades.
"""

from __future__ import annotations

import hashlib
import logging
import re
from pathlib import Path

from jarvis.config import settings

logger = logging.getLogger(__name__)

RAG_DIR = settings.RAG_DIR
DOCS_DIR = RAG_DIR / "documents"
CHROMA_DIR = RAG_DIR / "chroma_db"
DOCS_DIR.mkdir(parents=True, exist_ok=True)
CHROMA_DIR.mkdir(parents=True, exist_ok=True)

# Optional imports
try:
    import chromadb
    _CHROMA_OK = True
except ImportError:
    _CHROMA_OK = False

try:
    from sentence_transformers import SentenceTransformer
    _ST_OK = True
except ImportError:
    _ST_OK = False

try:
    import PyPDF2
    _PDF_OK = True
except ImportError:
    _PDF_OK = False

try:
    import docx
    _DOCX_OK = True
except ImportError:
    _DOCX_OK = False


class RAGEngine:
    """Document Q&A via retrieval-augmented generation."""

    def __init__(self) -> None:
        self._client = None
        self._collection = None
        self._model = None
        self._ready = False

        if not settings.RAG_ENABLED:
            return
        if not _CHROMA_OK or not _ST_OK:
            logger.info("RAG dependencies not installed. Install with: pip install jarvis-assistant[rag]")
            return
        try:
            self._client = chromadb.PersistentClient(path=str(CHROMA_DIR))
            self._collection = self._client.get_or_create_collection(
                name="jarvis_docs", metadata={"hnsw:space": "cosine"}
            )
            self._model = SentenceTransformer("all-MiniLM-L6-v2", device="cpu")
            self._ready = True
            logger.info("RAG engine ready.")
        except Exception as exc:
            logger.error("RAG init failed: %s", exc)

    @property
    def ready(self) -> bool:
        return self._ready

    # -- document ingestion --
    def add_document(self, filepath: Path) -> dict:
        """Parse, chunk, embed, and store a document."""
        if not self._ready:
            return {"success": False, "error": "RAG not initialised"}

        text = self._parse_file(filepath)
        if not text.strip():
            return {"success": False, "error": "Empty or unsupported file"}

        chunks = self._chunk_text(text)
        if not chunks:
            return {"success": False, "error": "No chunks produced"}

        doc_hash = hashlib.md5(f"{filepath.name}_{text[:100]}".encode()).hexdigest()
        ids = [f"{doc_hash}_{i}" for i in range(len(chunks))]
        embeddings = self._model.encode(chunks).tolist()
        metadatas = [{"source": filepath.name, "chunk_index": i} for i in range(len(chunks))]

        self._collection.add(ids=ids, embeddings=embeddings, documents=chunks, metadatas=metadatas)
        return {"success": True, "chunks": len(chunks)}

    # -- query --
    def query(self, question: str, n_results: int = 3) -> list[dict]:
        """Search the vector store and return the most relevant chunks."""
        if not self._ready:
            return []

        q_embedding = self._model.encode([question]).tolist()
        results = self._collection.query(
            query_embeddings=q_embedding,
            n_results=n_results,
            include=["documents", "metadatas", "distances"],
        )

        output = []
        if results and results["documents"]:
            for docs, metas, dists in zip(
                results["documents"], results["metadatas"], results["distances"]
            ):
                for doc, meta, dist in zip(docs, metas, dists):
                    output.append({
                        "text": doc,
                        "source": meta.get("source", "?"),
                        "score": round(1 - dist, 4),  # cosine distance → similarity
                    })
        return output

    # -- parsing --
    def _parse_file(self, path: Path) -> str:
        ext = path.suffix.lower()
        if ext == ".pdf" and _PDF_OK:
            with open(path, "rb") as f:
                reader = PyPDF2.PdfReader(f)
                return "\n".join(page.extract_text() or "" for page in reader.pages)
        if ext == ".docx" and _DOCX_OK:
            doc = docx.Document(str(path))
            return "\n".join(p.text for p in doc.paragraphs if p.text.strip())
        if ext in {".txt", ".md", ".py", ".js", ".html", ".css", ".json", ".csv", ".yaml", ".yml",
                   ".c", ".cpp", ".java", ".go", ".rs", ".ts"}:
            for enc in ("utf-8", "latin-1"):
                try:
                    return path.read_text(encoding=enc)
                except UnicodeDecodeError:
                    continue
        return ""

    # -- chunking --
    def _chunk_text(self, text: str, size: int = 512, overlap: int = 128) -> list[str]:
        text = re.sub(r"\n{3,}", "\n\n", text).strip()
        if len(text) <= size:
            return [text]
        chunks: list[str] = []
        start = 0
        while start < len(text):
            end = min(start + size, len(text))
            if end < len(text):
                # try to break at paragraph or sentence
                for sep in ["\n\n", ". ", "\n", " "]:
                    pos = text.rfind(sep, start + size // 2, end)
                    if pos > start:
                        end = pos + len(sep)
                        break
            chunk = text[start:end].strip()
            if chunk:
                chunks.append(chunk)
            start = end - overlap
            if start >= end:
                start = end
        return chunks
