"""
Security helpers — input sanitisation, sandbox validation.
"""

from __future__ import annotations

import ast
import re

# Python builtins / modules that are NEVER allowed inside run_python
BLOCKED_IMPORTS: set[str] = {
    "os", "sys", "subprocess", "shutil", "ctypes",
    "socket", "http", "urllib", "requests", "webbrowser",
    "signal", "threading", "multiprocessing", "pickle",
    "marshal", "importlib", "builtins", "code", "codeop",
    "compile", "compileall",
}

# Shell commands that are never allowed
BLOCKED_COMMANDS: set[str] = {
    "rm -rf /", "mkfs", "format", "del /", "del \\",
    "shutdown", "reboot", "init 0",
}


def validate_python_sandbox(code: str) -> tuple[bool, str]:
    """Check whether Python *code* looks safe for sandboxed execution.

    Returns (is_safe, reason).
    This is a heuristic check — NOT a true sandbox.
    """
    try:
        tree = ast.parse(code)
    except SyntaxError as exc:
        return False, f"Syntax error: {exc}"

    for node in ast.walk(tree):
        # Block import statements
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            names = []
            if isinstance(node, ast.Import):
                names = [alias.name.split(".")[0] for alias in node.names]
            else:
                names = [node.module.split(".")[0]] if node.module else []
            for name in names:
                if name in BLOCKED_IMPORTS:
                    return False, f"Blocked import: {name}"

        # Block exec / eval / compile / __import__
        if isinstance(node, ast.Call):
            func = node.func
            if isinstance(func, ast.Name) and func.id in {"exec", "eval", "compile", "__import__"}:
                return False, f"Blocked call: {func.id}()"
            if isinstance(func, ast.Attribute) and func.attr in {"exec", "eval"}:
                return False, f"Blocked call: .{func.attr}()"

    return True, "OK"


def validate_shell_command(cmd: str) -> tuple[bool, str]:
    """Check whether a shell command is on the blocklist."""
    normalised = re.sub(r"\s+", " ", cmd.strip().lower())
    for blocked in BLOCKED_COMMANDS:
        if blocked in normalised:
            return False, f"Blocked command: {cmd!r}"
    return True, "OK"


def redact_api_key(text: str) -> str:
    """Mask any Groq / OpenAI-style API key in *text*."""
    return re.sub(r"(sk-[A-Za-z0-9]{16,}|gsk_[A-Za-z0-9]{16,})", "****REDACTED****", text)
