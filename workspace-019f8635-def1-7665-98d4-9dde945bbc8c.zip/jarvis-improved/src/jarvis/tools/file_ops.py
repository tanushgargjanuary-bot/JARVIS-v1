"""File operations tool — read / write / list files in the notes directory."""

from __future__ import annotations

import json

from jarvis.config import settings
from jarvis.tools import tool
from jarvis.utils import safe_resolve

# Only allow operations inside NOTES_DIR
_BASE = settings.NOTES_DIR


@tool(
    "file_operations",
    "Read, write, list, or search files in the notes directory.",
    {
        "action": {"type": "string", "enum": ["read", "write", "list", "search"], "description": "File operation"},
        "path": {"type": "string", "description": "File or directory path (relative to notes/)"},
        "content": {"type": "string", "description": "Content for write operation"},
    },
)
def file_operations(action: str, path: str = ".", content: str = "") -> str:
    """Perform file operations inside the notes directory."""
    try:
        if action == "list":
            target = safe_resolve(_BASE, path) or _BASE
            if not target.is_dir():
                return f"Not a directory: {path}"
            entries = [f.name for f in target.iterdir()][:50]
            return json.dumps(entries)

        if action == "read":
            target = safe_resolve(_BASE, path)
            if target is None or not target.is_file():
                return f"File not found: {path}"
            text = target.read_text(encoding="utf-8", errors="replace")
            return text[:5000]  # cap output

        if action == "write":
            target = safe_resolve(_BASE, path)
            if target is None:
                return f"Invalid path: {path}"
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
            return f"Wrote {len(content)} chars to {path}"

        if action == "search":
            results = []
            for f in _BASE.rglob("*"):
                if f.is_file() and path.lower() in f.name.lower():
                    results.append(f.name)
            return json.dumps(results[:50]) if results else f"No files matching '{path}'"

        return f"Unknown action: {action}"
    except Exception as exc:
        return f"File operation error: {exc}"
