"""
JARVIS configuration loader.

Reads settings from .env and provides typed, validated access.
All configuration in one place — no scattered os.getenv() calls.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
# BASE_DIR: where the user's .env lives (cwd at runtime)
BASE_DIR = Path.cwd()

# User-data directories (created lazily on first use)
MEMORY_DIR = BASE_DIR / "memory"
NOTES_DIR = BASE_DIR / "notes"
SCREENSHOTS_DIR = BASE_DIR / "screenshots"
LOGS_DIR = BASE_DIR / "logs"
RAG_DIR = BASE_DIR / "rag"

for _d in [MEMORY_DIR, NOTES_DIR, SCREENSHOTS_DIR, LOGS_DIR, RAG_DIR]:
    _d.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# Env loader
# ---------------------------------------------------------------------------
load_dotenv(BASE_DIR / ".env")


def _env(key: str, default: str = "") -> str:
    return os.getenv(key, default)


def _env_bool(key: str, default: bool = False) -> bool:
    return _env(key, str(default)).strip().lower() in ("true", "1", "yes")


def _env_int(key: str, default: int = 0) -> int:
    try:
        return int(_env(key, str(default)))
    except ValueError:
        return default


def _env_float(key: str, default: float = 0.0) -> float:
    try:
        return float(_env(key, str(default)))
    except ValueError:
        return default


# ---------------------------------------------------------------------------
# Settings dataclass-like container
# ---------------------------------------------------------------------------
class Settings:
    """Central, typed configuration object.

    All values come from environment / .env file with sensible defaults.
    Path attributes point to user-data directories (auto-created).
    """

    # --- required ---
    GROQ_API_KEY: str = _env("GROQ_API_KEY", "")

    # --- personalization ---
    OWNER_NAME: str = _env("OWNER_NAME", "Boss")
    CITY: str = _env("CITY", "New Delhi")

    # --- voice ---
    WAKE_WORD: str = _env("WAKE_WORD", "jarvis").lower()
    VOICE_SPEED: int = _env_int("VOICE_SPEED", 172)
    VOICE_ENABLED: bool = _env_bool("VOICE_ENABLED", True)

    # --- AI model ---
    AI_MODEL: str = _env("AI_MODEL", "llama-3.1-8b-instant")
    MAX_TOKENS: int = _env_int("MAX_TOKENS", 512)
    TEMPERATURE: float = _env_float("TEMPERATURE", 0.7)
    MAX_MEMORY: int = _env_int("MAX_MEMORY", 30)

    # --- feature flags ---
    AGENT_TOOLS_ENABLED: bool = _env_bool("AGENT_TOOLS_ENABLED", True)
    RAG_ENABLED: bool = _env_bool("RAG_ENABLED", True)

    # --- paths ---
    BASE_DIR: Path = BASE_DIR
    MEMORY_DIR: Path = MEMORY_DIR
    NOTES_DIR: Path = NOTES_DIR
    SCREENSHOTS_DIR: Path = SCREENSHOTS_DIR
    LOGS_DIR: Path = LOGS_DIR
    RAG_DIR: Path = RAG_DIR

    @classmethod
    def validate(cls) -> list[str]:
        """Return a list of configuration warnings."""
        warnings: list[str] = []
        if not cls.GROQ_API_KEY or cls.GROQ_API_KEY == "your_groq_key_here":
            warnings.append(
                "GROQ_API_KEY is not set. AI features will not work. "
                "Get a free key at https://console.groq.com/keys"
            )
        return warnings

    @classmethod
    def as_dict(cls) -> dict[str, Any]:
        """Export all settings as a dict (useful for UI panels)."""
        return {
            k: v
            for k, v in vars(cls).items()
            if not k.startswith("_") and isinstance(v, (str, int, float, bool))
        }


# Singleton instance for convenience
settings = Settings
