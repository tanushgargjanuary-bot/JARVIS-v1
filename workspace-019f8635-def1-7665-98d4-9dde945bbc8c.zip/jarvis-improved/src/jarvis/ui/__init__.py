"""
UI module — CustomTkinter dark-themed interface.

Falls back to terminal-only mode if customtkinter is not installed.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

try:
    import customtkinter as ctk  # noqa: F401
    _CTK_OK = True
except ImportError:
    _CTK_OK = False


def is_ui_available() -> bool:
    return _CTK_OK


if _CTK_OK:
    from jarvis.ui.app import JarvisApp  # noqa: F401
