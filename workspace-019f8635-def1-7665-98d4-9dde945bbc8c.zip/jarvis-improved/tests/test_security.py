"""Tests for security helpers."""

from __future__ import annotations

from jarvis.utils.security import validate_python_sandbox, validate_shell_command, redact_api_key


class TestPythonSandbox:
    def test_safe_code(self):
        ok, reason = validate_python_sandbox("x = 2 + 3\nprint(x)")
        assert ok is True

    def test_block_os_import(self):
        ok, reason = validate_python_sandbox("import os; os.system('ls')")
        assert ok is False
        assert "os" in reason

    def test_block_subprocess(self):
        ok, reason = validate_python_sandbox("import subprocess")
        assert ok is False

    def test_block_exec(self):
        ok, reason = validate_python_sandbox("exec('print(1)')")
        assert ok is False

    def test_block_eval(self):
        ok, reason = validate_python_sandbox("eval('1+1')")
        assert ok is False

    def test_block_dunder_import(self):
        ok, reason = validate_python_sandbox("__import__('os')")
        assert ok is False

    def test_syntax_error(self):
        ok, reason = validate_python_sandbox("def (")
        assert ok is False


class TestShellCommand:
    def test_safe_command(self):
        ok, _ = validate_shell_command("echo hello")
        assert ok is True

    def test_block_dangerous(self):
        ok, _ = validate_shell_command("rm -rf /")
        assert ok is False

    def test_block_shutdown(self):
        ok, _ = validate_shell_command("shutdown -h now")
        assert ok is False


class TestRedaction:
    def test_redact_groq_key(self):
        text = "My key is gsk_abcdefghijklmnop1234 and it works."
        redacted = redact_api_key(text)
        assert "REDACTED" in redacted
        assert "gsk_abcdefghijklmnop1234" not in redacted

    def test_redact_openai_key(self):
        text = "Key: sk-abcdefghij1234567890"
        redacted = redact_api_key(text)
        assert "REDACTED" in redacted

    def test_no_false_positive(self):
        text = "Nothing sensitive here."
        assert redact_api_key(text) == text
