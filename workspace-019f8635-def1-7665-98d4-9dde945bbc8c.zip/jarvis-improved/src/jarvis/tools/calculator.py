"""Calculator tool — safe math evaluation."""

from __future__ import annotations

import math
import re

from jarvis.tools import tool

# Allowed names for the safe eval namespace
_SAFE_NAMES = {
    "abs": abs, "round": round, "min": min, "max": max,
    "sqrt": math.sqrt, "log": math.log, "log10": math.log10,
    "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "pi": math.pi, "e": math.e,
    "pow": pow, "ceil": math.ceil, "floor": math.floor,
}


@tool(
    "calculator",
    "Perform mathematical calculations including arithmetic, algebra, trigonometry, and logarithms.",
    {"expression": {"type": "string", "description": "Math expression to evaluate"}},
)
def calculator(expression: str) -> str:
    """Safely evaluate a math expression."""
    # Normalise natural-language operators
    expr = expression.lower()
    expr = expr.replace("percent of", "/ 100 *")
    expr = expr.replace("percent", "/ 100")
    expr = expr.replace("times", "*")
    expr = expr.replace("plus", "+")
    expr = expr.replace("minus", "-")
    expr = expr.replace("divided by", "/")

    # Only allow safe characters
    if not re.match(r'^[\d\s\+\-\*\/\.\(\)%a-z_]+$', expr):
        return f"Cannot evaluate: {expression}"

    try:
        result = eval(expr, {"__builtins__": {}}, _SAFE_NAMES)  # noqa: S307
        if isinstance(result, float) and result == int(result):
            result = int(result)
        return f"{expression} = {result}"
    except Exception as exc:
        return f"Calculator error: {exc}"
