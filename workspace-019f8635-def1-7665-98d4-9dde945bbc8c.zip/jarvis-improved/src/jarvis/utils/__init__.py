"""
Utility helpers — platform detection, safe file paths, etc.
"""

from __future__ import annotations

import platform
import shutil
import subprocess
from pathlib import Path


def get_platform() -> str:
    """Return 'windows', 'darwin', or 'linux'."""
    return platform.system().lower()


def is_windows() -> bool:
    return get_platform() == "windows"


def is_macos() -> bool:
    return get_platform() == "darwin"


def is_linux() -> bool:
    return get_platform() == "linux"


def find_executable(name: str) -> str | None:
    """Locate an executable on PATH (cross-platform).

    Accepts a bare name like 'code' or 'firefox'.
    Returns the full path or None.
    """
    return shutil.which(name)


def open_url(url: str) -> None:
    """Open a URL in the default browser (cross-platform)."""
    import webbrowser
    webbrowser.open(url)


def open_file(path: str | Path) -> None:
    """Open a file with the OS default application."""
    path = str(path)
    system = get_platform()
    if system == "windows":
        os_startfile(path)  # type: ignore[name-defined]
    elif system == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


# Windows-only helper (imported lazily to avoid import errors elsewhere)
def os_startfile(path: str) -> None:
    import os
    if hasattr(os, "startfile"):
        os.startfile(path)  # type: ignore[attr-defined]
    else:
        subprocess.Popen(["xdg-open", path])


def safe_resolve(base: Path, user_path: str) -> Path | None:
    """Resolve *user_path* relative to *base* and ensure it doesn't escape.

    Returns the resolved path if it is under *base*, else None.
    This prevents directory-traversal attacks in file tools.
    """
    resolved = (base / user_path).resolve()
    if resolved.is_relative_to(base.resolve()):
        return resolved
    return None
