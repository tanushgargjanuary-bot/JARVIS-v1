"""
Daily assistant commands — time, date, reminders, pomodoro, morning briefing.
"""

from __future__ import annotations

import threading
import time
from datetime import datetime

from jarvis.commands import register
from jarvis.config import settings
from jarvis.voice import speak

# ---------------------------------------------------------------------------
# Time / Date
# ---------------------------------------------------------------------------

@register(r"^(?:what(?:'s| is) the )?time|what time is it", category="daily", description="Current time")
def get_time() -> str:
    now = datetime.now()
    return f"It's {now.strftime('%I:%M %p')}."


@register(r"^(?:what(?:'s| is) the )?date|what day is (?:it|today)", category="daily", description="Current date")
def get_date() -> str:
    now = datetime.now()
    return f"Today is {now.strftime('%A, %B %d, %Y')}."


# ---------------------------------------------------------------------------
# Reminder
# ---------------------------------------------------------------------------

_reminder_threads: list[threading.Thread] = []


@register(
    r"^set (?:a )?reminder (?:in )?(?P<minutes>\d+) (?:minutes?|mins?) (?P<msg>.+)",
    category="daily",
    description="Set a timed reminder",
)
def set_reminder(minutes: str, msg: str) -> str:
    """Set a reminder that fires after *minutes*."""
    mins = int(minutes)

    def _wait() -> None:
        time.sleep(mins * 60)
        speak(f"Reminder: {msg}")

    t = threading.Thread(target=_wait, daemon=True)
    t.start()
    _reminder_threads.append(t)
    return f"Reminder set for {mins} minute(s): {msg}"


# ---------------------------------------------------------------------------
# Pomodoro
# ---------------------------------------------------------------------------

_pomodoro_active = False
_pomodoro_thread: threading.Thread | None = None


@register(
    r"^(?:start )?pomodoro(?: for (?P<minutes>\d+) minutes?)?",
    category="daily",
    description="Start a Pomodoro timer",
)
def pomodoro_timer(minutes: str = "25") -> str:
    """Start a Pomodoro session."""
    global _pomodoro_active, _pomodoro_thread
    if _pomodoro_active:
        return "A Pomodoro session is already running."

    mins = int(minutes)
    _pomodoro_active = True

    def _run() -> None:
        global _pomodoro_active
        checkpoint = 5
        elapsed = 0
        while elapsed < mins and _pomodoro_active:
            time.sleep(checkpoint * 60)
            elapsed += checkpoint
            if _pomodoro_active:
                speak(f"{mins - elapsed} minutes remaining in your Pomodoro.")
        if _pomodoro_active:
            speak("Pomodoro complete! Take a break.")
        _pomodoro_active = False

    _pomodoro_thread = threading.Thread(target=_run, daemon=True)
    _pomodoro_thread.start()
    return f"Pomodoro started for {mins} minutes."


@register(r"^stop pomodoro", category="daily", description="Stop Pomodoro timer")
def stop_pomodoro() -> str:
    global _pomodoro_active
    if not _pomodoro_active:
        return "No Pomodoro session is running."
    _pomodoro_active = False
    return "Pomodoro stopped."


# ---------------------------------------------------------------------------
# Morning briefing
# ---------------------------------------------------------------------------

@register(r"^morning briefing|good morning", category="daily", description="Morning briefing")
def morning_briefing() -> str:
    """Return a morning briefing: time + weather + motivation."""
    from jarvis.commands.web import get_weather

    greeting = _time_greeting()
    weather = get_weather()
    return f"{greeting} Weather: {weather}"


def _time_greeting() -> str:
    hour = datetime.now().hour
    if hour < 12:
        return f"Good morning, {settings.OWNER_NAME}!"
    elif hour < 17:
        return f"Good afternoon, {settings.OWNER_NAME}!"
    else:
        return f"Good evening, {settings.OWNER_NAME}!"
