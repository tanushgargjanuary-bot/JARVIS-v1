"""System info tool — CPU, RAM, disk, battery."""

from __future__ import annotations

import json
from datetime import datetime

import psutil

from jarvis.tools import tool


@tool(
    "system_info",
    "Get detailed system information: CPU, RAM, disk, battery, uptime.",
    {"detail": {"type": "string", "enum": ["basic", "detailed"], "default": "basic", "description": "Level of detail"}},
)
def system_info(detail: str = "basic") -> str:
    """Return system information as JSON."""
    cpu = psutil.cpu_percent(interval=0.5)
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    battery = psutil.sensors_battery()

    info = {
        "cpu_percent": cpu,
        "ram_percent": mem.percent,
        "ram_used_gb": round(mem.used / (1024 ** 3), 1),
        "ram_total_gb": round(mem.total / (1024 ** 3), 1),
        "disk_percent": disk.percent,
    }
    if battery:
        info["battery_percent"] = battery.percent
        info["battery_charging"] = battery.power_plugged

    if detail == "detailed":
        boot = datetime.fromtimestamp(psutil.boot_time())
        info["uptime"] = str(datetime.now() - boot).split(".")[0]
        info["cpu_cores_physical"] = psutil.cpu_count(logical=False)
        info["cpu_cores_logical"] = psutil.cpu_count(logical=True)
        info["top_processes"] = [
            {"pid": p.pid, "name": p.name(), "cpu": p.cpu_percent()}
            for p in sorted(psutil.process_iter(["pid", "name", "cpu_percent"]),
                            key=lambda p: p.cpu_percent() or 0, reverse=True)[:5]
        ]

    return json.dumps(info, indent=2)
