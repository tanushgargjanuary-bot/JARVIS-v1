"""DateTime tool — current date/time queries and calculations."""

from __future__ import annotations

from datetime import datetime

from jarvis.tools import tool


@tool(
    "datetime_tool",
    "Get current date/time info or perform date calculations.",
    {
        "query": {
            "type": "string",
            "enum": ["now", "today", "weekday", "year", "days_until"],
            "description": "What to query",
            "default": "now",
        },
        "date": {"type": "string", "description": "Date for days_until (YYYY-MM-DD)"},
    },
)
def datetime_tool(query: str = "now", date: str = "") -> str:
    """Answer date/time questions."""
    now = datetime.now()

    if query == "now":
        return now.strftime("%Y-%m-%d %H:%M:%S (%A)")
    elif query == "today":
        return now.strftime("%A, %B %d, %Y")
    elif query == "weekday":
        return now.strftime("%A")
    elif query == "year":
        return str(now.year)
    elif query == "days_until" and date:
        try:
            target = datetime.strptime(date, "%Y-%m-%d")
            delta = (target - now).days
            return f"{delta} days until {date}"
        except ValueError:
            return f"Invalid date format: {date}. Use YYYY-MM-DD."
    return f"Unknown query: {query}"
