"""
Fun commands — jokes, motivation, facts, coin flip, dice roll.
"""

from __future__ import annotations

import random

from jarvis.commands import register

# ---------------------------------------------------------------------------
# Jokes
# ---------------------------------------------------------------------------

@register(r"^(?:tell (?:me )?a )?joke", category="fun", description="Tell a programming joke")
def tell_joke() -> str:
    try:
        import pyjokes  # type: ignore[import-untyped]
        return pyjokes.get_joke()
    except ImportError:
        return _fallback_joke()


def _fallback_joke() -> str:
    jokes = [
        "Why do programmers prefer dark mode? Because light attracts bugs.",
        "There are only 10 types of people: those who understand binary and those who don't.",
        "A SQL query walks into a bar, walks up to two tables and asks: 'Can I join you?'",
        "Why did the developer go broke? Because he used up all his cache.",
    ]
    return random.choice(jokes)


# ---------------------------------------------------------------------------
# Motivation
# ---------------------------------------------------------------------------

_QUOTES = [
    "The only way to do great work is to love what you do. — Steve Jobs",
    "Code is like humor. When you have to explain it, it's bad. — Cory House",
    "First, solve the problem. Then, write the code. — John Johnson",
    "Simplicity is the soul of efficiency. — Austin Freeman",
    "Talk is cheap. Show me the code. — Linus Torvalds",
    "Any fool can write code a computer understands. Good programmers write code humans understand."
    " — Martin Fowler",
    "The best error message is the one that never shows up. — Thomas Fuchs",
    "Programs must be written for people to read, and only incidentally for machines to execute. — Harold Abelson",
]


@register(r"^(?:motivate me|give me a quote|inspirational quote)", category="fun", description="Motivational quote")
def motivate() -> str:
    return random.choice(_QUOTES)


# ---------------------------------------------------------------------------
# Fun facts
# ---------------------------------------------------------------------------

_FACTS = [
    "The first computer bug was an actual bug — a moth found in a Harvard Mark II in 1947.",
    "Python is named after the comedy troupe Monty Python, not the snake.",
    "The first 1GB hard drive, made by IBM in 1980, weighed over 500 pounds and cost $40,000.",
    "About 90% of the world's data has been created in the last two years.",
    "The average person checks their phone 96 times a day — that's once every 10 minutes.",
    "Linux powers 100% of the world's top 500 supercomputers.",
]


@register(r"^(?:tell me a )?(?:fun )?fact", category="fun", description="Random fun fact")
def fun_fact() -> str:
    return random.choice(_FACTS)


# ---------------------------------------------------------------------------
# Coin flip / Dice roll
# ---------------------------------------------------------------------------

@register(r"^flip (?:a )?coin", category="fun", description="Flip a coin")
def flip_coin() -> str:
    result = random.choice(["heads", "tails"])
    return f"It's {result}!"


@register(r"^roll (?:a )?(?P<sides>\d+)-?sided dice|roll (?:a )?dice", category="fun", description="Roll a dice")
def roll_dice(sides: str = "6") -> str:
    n = int(sides) if sides else 6
    result = random.randint(1, n)
    return f"You rolled a {result} on a {n}-sided die."


# ---------------------------------------------------------------------------
# Calculator
# ---------------------------------------------------------------------------

@register(r"^(?:calculate|calc|what(?:'s| is)) (?P<expr>.+)", category="fun", description="Basic calculator")
def calculate(expr: str) -> str:
    """Evaluate a math expression safely."""
    import re as _re

    # Normalise words to operators
    text = expr.lower()
    text = text.replace("percent of", "/ 100 *")
    text = text.replace("percent", "/ 100")
    text = text.replace("times", "*")
    text = text.replace("x", "*")
    text = text.replace("plus", "+")
    text = text.replace("minus", "-")
    text = text.replace("divided by", "/")

    # Only allow safe characters
    if not _re.match(r'^[\d\s\+\-\*\/\.\(\)%]+$', text):
        return f"Cannot evaluate: {expr}"

    try:
        result = eval(text, {"__builtins__": {}}, {})  # noqa: S307
        # Format nicely
        if isinstance(result, float) and result == int(result):
            return f"{expr} = {int(result)}"
        return f"{expr} = {result}"
    except Exception:
        return f"Could not calculate: {expr}"
