"""
PC control commands — open / close apps, volume, brightness, screenshots, system info.

These commands are largely platform-aware:
- Windows uses taskkill / os.startfile
- macOS uses `open` / `osascript`
- Linux uses xdg-open / xdotool
"""

from __future__ import annotations

import logging
import platform
import re
import subprocess
from datetime import datetime

import psutil

from jarvis.commands import register
from jarvis.config import settings
from jarvis.utils import find_executable, is_macos, is_windows

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# App registry — uses `which` for cross-platform discovery
# ---------------------------------------------------------------------------

# Map friendly name -> list of possible binary names / paths
_APP_ALIASES: dict[str, list[str]] = {
    "chrome": ["google-chrome", "google-chrome-stable", "chrome"],
    "firefox": ["firefox"],
    "brave": ["brave-browser", "brave"],
    "edge": ["microsoft-edge", "msedge"],
    "vscode": ["code", "cursor"],
    "notepad": ["notepad", "gedit", "xed", "gnome-text-editor"],
    "calculator": ["calc", "gnome-calculator", "kcalc"],
    "terminal": ["wt", "cmd", "powershell", "gnome-terminal", "konsole", "xterm"],
    "file manager": ["explorer", "nautilus", "dolphin", "thunar"],
    "vlc": ["vlc"],
    "spotify": ["spotify"],
    "discord": ["discord"],
    "telegram": ["telegram-desktop", "telegram"],
}

# Apps safe to kill
_SAFE_CLOSE: set[str] = {
    "notepad", "chrome", "firefox", "brave", "edge", "code",
    "vlc", "spotify", "discord", "telegram", "calc",
}


# ---------------------------------------------------------------------------
# open app
# ---------------------------------------------------------------------------

@register(r"^open (?P<name>.+)", category="pc", description="Open an application")
def open_app(name: str) -> str:
    """Open an application by name."""
    name_lower = name.lower().strip()

    # Try alias list
    for alias, binaries in _APP_ALIASES.items():
        if alias in name_lower or name_lower in alias:
            for binary in binaries:
                path = find_executable(binary)
                if path:
                    subprocess.Popen([path])
                    return f"Opening {alias}."

    # Direct binary lookup
    path = find_executable(name_lower.replace(" ", "-"))
    if path:
        subprocess.Popen([path])
        return f"Opening {name_lower}."

    # Windows: try start command
    if is_windows():
        try:
            subprocess.Popen(f'start {name_lower}', shell=True)
            return f"Opening {name_lower}."
        except Exception:
            pass

    # macOS: try open -a
    if is_macos():
        try:
            subprocess.Popen(["open", "-a", name])
            return f"Opening {name}."
        except Exception:
            pass

    return f"I don't know how to open '{name}'. You can add it to the app aliases."


# ---------------------------------------------------------------------------
# close app
# ---------------------------------------------------------------------------

@register(r"^(?:close|kill|quit) (?P<name>.+)", category="pc", description="Close an application")
def close_app(name: str) -> str:
    """Close an application safely."""
    name_lower = name.lower().strip()

    if name_lower not in _SAFE_CLOSE:
        return f"'{name}' is not in the safe-close list. Close it manually to be safe."

    system = platform.system().lower()
    try:
        if system == "windows":
            subprocess.run(
                ["taskkill", "/IM", f"{name_lower}.exe", "/F"],
                capture_output=True, text=True, timeout=10,
            )
        elif system == "darwin":
            subprocess.run(["pkill", "-f", name_lower], capture_output=True, timeout=10)
        else:
            subprocess.run(["pkill", "-f", name_lower], capture_output=True, timeout=10)
        return f"Closed {name_lower}."
    except Exception as exc:
        return f"Error closing {name_lower}: {exc}"


# ---------------------------------------------------------------------------
# Volume
# ---------------------------------------------------------------------------

@register(r"^volume (?P<action>up|down|mute|unmute)", category="pc", description="Control volume")
def volume_control(action: str) -> str:
    """Control system volume."""
    try:
        import pyautogui  # type: ignore[import-untyped]
        if action in ("up",):
            pyautogui.press("volumeup", presses=5)
            return "Volume increased."
        elif action in ("down",):
            pyautogui.press("volumedown", presses=5)
            return "Volume decreased."
        elif action in ("mute", "unmute"):
            pyautogui.press("volumemute")
            return f"Volume {'muted' if action == 'mute' else 'unmuted'}."
    except ImportError:
        return "Volume control requires pyautogui. Install with: pip install jarvis-assistant[gui]"
    return "Volume command not recognised."


# ---------------------------------------------------------------------------
# Brightness
# ---------------------------------------------------------------------------

@register(r"^brightness (?P<action>up|down|to \d+)", category="pc", description="Control brightness")
def brightness_control(action: str) -> str:
    """Control screen brightness."""
    try:
        import screen_brightness_control as sbc  # type: ignore[import-untyped]
    except ImportError:
        return "Brightness control requires screen-brightness-control. Install: pip install jarvis-assistant[gui]"

    try:
        current = sbc.get_brightness()[0] if isinstance(sbc.get_brightness(), list) else sbc.get_brightness()
        if action in ("up",):
            new_val = min(100, current + 20)
        elif action in ("down",):
            new_val = max(0, current - 20)
        elif action.startswith("to "):
            new_val = int(re.search(r"\d+", action).group())  # type: ignore[union-attr]
            new_val = max(0, min(100, new_val))
        else:
            return "Brightness command not recognised."

        sbc.set_brightness(new_val)
        return f"Brightness set to {new_val}%."
    except Exception as exc:
        return f"Brightness control error: {exc}"


# ---------------------------------------------------------------------------
# Screenshot
# ---------------------------------------------------------------------------

@register(r"^screenshot|take a screenshot", category="pc", description="Take a screenshot")
def take_screenshot() -> str:
    """Take a screenshot and save it."""
    try:
        import pyautogui  # type: ignore[import-untyped]
    except ImportError:
        return "Screenshots require pyautogui. Install: pip install jarvis-assistant[gui]"

    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = settings.SCREENSHOTS_DIR / f"screenshot_{timestamp}.png"
        screenshot = pyautogui.screenshot()
        screenshot.save(str(filepath))
        return f"Screenshot saved: {filepath.name}"
    except Exception as exc:
        return f"Screenshot failed: {exc}"


# ---------------------------------------------------------------------------
# System info
# ---------------------------------------------------------------------------

@register(r"^system info|sysinfo", category="pc", description="Show system info")
def system_info() -> str:
    """Return basic system information."""
    cpu = psutil.cpu_percent(interval=0.5)
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    battery = psutil.sensors_battery()

    lines = [
        f"CPU: {cpu}%",
        f"RAM: {mem.percent}% ({mem.used // (1024**3)}GB / {mem.total // (1024**3)}GB)",
        f"Disk: {disk.percent}% used",
    ]
    if battery:
        lines.append(f"Battery: {battery.percent}%{' (charging)' if battery.power_plugged else ''}")
    lines.append(f"Uptime: {_format_uptime()}")
    return " | ".join(lines)


def _format_uptime() -> str:
    boot = datetime.fromtimestamp(psutil.boot_time())
    delta = datetime.now() - boot
    hours, remainder = divmod(int(delta.total_seconds()), 3600)
    minutes = remainder // 60
    return f"{hours}h {minutes}m"
