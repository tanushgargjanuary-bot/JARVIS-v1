# JARVIS v2 — AI Voice Assistant

A lightweight, cross-platform AI voice assistant powered by the **Groq API** (Llama 3). Built with Python, featuring voice/text control, persistent chat history, document Q&A, and agent tool calling.

> **Originally forked from [JARVIS-v0](https://github.com/talibmakhdum/JARVIS-v0)** by talibmakhdum. This is a major refactor and rewrite with proper packaging, cross-platform support, tests, and security improvements.

---

## Why v2?

The v1 codebase was a 2-day AI-generated dump with hardcoded Windows paths, no tests, no license, and security issues. v2 is a ground-up restructure:

| | v1 | v2 |
|---|---|---|
| **Platform** | Windows only | Windows, macOS, Linux |
| **Packaging** | Raw `.py` files + `.bat` scripts | `pyproject.toml`, `pip install -e .`, `jarvis` CLI |
| **Tests** | One broken test file | Full pytest suite, GitHub Actions CI |
| **License** | None (all rights reserved) | MIT |
| **Security** | Shell injection, `FAILSAFE=False` | Sandbox validation, path traversal protection |
| **Dependencies** | All-or-nothing install | Optional extras (`[voice]`, `[rag]`, `[gui]`, `[ui]`) |
| **Architecture** | 7 god-files (6400 lines) | Proper package with separated concerns |

---

## Quick Start

### 1. Install

```bash
git clone https://github.com/YOUR_USERNAME/jarvis-improved.git
cd jarvis-improved

# Linux / macOS
bash scripts/install.sh

# Windows
scripts\install.bat
```

Or manually:

```bash
python -m venv .venv
source .venv/bin/activate  # or .venv\Scripts\activate on Windows
pip install -e ".[all]"    # or pick extras: [voice] [gui] [ui] [rag]
```

### 2. Configure

```bash
cp .env.example .env
# Edit .env — add your Groq API key
```

Get a **free** API key at [console.groq.com/keys](https://console.groq.com/keys).

### 3. Run

```bash
# Auto-detect mode (GUI if available, else terminal)
jarvis

# Force terminal mode
jarvis --terminal

# Force voice mode
jarvis --voice

# Force GUI mode
jarvis --gui
```

---

## Features

### Voice & Text Commands

Say or type commands like:

| Command | Action |
|---|---|
| `open firefox` | Launch an app (cross-platform) |
| `close chrome` | Close an app |
| `volume up/down/mute` | Control volume |
| `brightness up/down` | Control brightness |
| `screenshot` | Take a screenshot |
| `system info` | CPU, RAM, disk, battery |
| `go to github` | Open a website |
| `search for python tutorials` | Google search |
| `search youtube for lofi` | YouTube search |
| `weather in Delhi` | Current weather |
| `create note` | Voice-dictated note |
| `read my last note` | Read notes back |
| `tell me a joke` | Programming joke |
| `motivate me` | Inspirational quote |
| `flip a coin` / `roll dice` | Random fun |
| `calculate 15% of 3000` | Math evaluation |
| `what time is it` | Current time |
| `set reminder 5 mins drink water` | Timed reminder |
| `start pomodoro 25 minutes` | Pomodoro timer |
| `explain quicksort` | CS concept (via AI) |
| `complexity of binary search` | Big-O analysis |

### AI Brain

Any query that doesn't match a local command is sent to the Groq API (Llama 3) with conversation memory. The AI can also use **agent tools** when enabled:

- `web_search` — DuckDuckGo search
- `calculator` — Safe math evaluation
- `system_info` — System statistics
- `datetime_tool` — Date/time queries
- `file_operations` — Read/write files in notes/

### Chat History

All conversations are persisted in SQLite. You can search, pin, and manage conversations through the chat database.

### RAG Document Q&A *(optional)*

Upload PDFs, text files, code, and documents. JARVIS chunks them, embeds them with sentence-transformers, and answers questions using vector search.

```bash
pip install -e ".[rag]"
```

### Modern UI *(optional)*

Dark-themed CustomTkinter interface with sidebar navigation, chat panel, and status indicators.

```bash
pip install -e ".[ui]"
```

---

## Project Structure

```
jarvis-improved/
├── src/jarvis/
│   ├── __init__.py          # Package metadata
│   ├── __main__.py          # Entry point (jarvis CLI)
│   ├── config.py            # Settings from .env
│   ├── voice.py             # TTS + STT (graceful degradation)
│   ├── brain.py             # Groq API + conversation memory
│   ├── commands/            # Pattern-matched command handlers
│   │   ├── __init__.py      # Router + @register decorator
│   │   ├── pc_control.py    # App launch/close, volume, brightness
│   │   ├── web.py           # Websites, search, weather
│   │   ├── notes.py         # Note management
│   │   ├── daily.py         # Time, reminders, pomodoro
│   │   ├── fun.py           # Jokes, quotes, calculator
│   │   └── cse.py           # CS student tools (via AI)
│   ├── tools/               # Agent tools for function calling
│   │   ├── __init__.py      # ToolExecutor + @tool decorator
│   │   ├── web_search.py    # DuckDuckGo
│   │   ├── calculator.py    # Safe math
│   │   ├── file_ops.py      # Sandboxed file operations
│   │   ├── system_info.py   # CPU/RAM/disk
│   │   └── datetime_tool.py # Date/time queries
│   ├── rag/                 # RAG document Q&A
│   │   └── engine.py        # Parse, chunk, embed, search
│   ├── storage/             # Persistent chat history
│   │   └── chat_db.py       # SQLite with WAL mode
│   ├── ui/                  # CustomTkinter GUI
│   │   ├── app.py           # Main window
│   │   └── theme.py         # Dark theme constants
│   └── utils/               # Helpers
│       ├── __init__.py      # Platform detection, safe paths
│       └── security.py      # Sandbox validation, redaction
├── tests/                   # pytest suite
├── .github/workflows/ci.yml # GitHub Actions CI
├── pyproject.toml           # Modern Python packaging
├── LICENSE                  # MIT
└── .env.example             # Config template
```

---

## Configuration

All settings live in `.env`:

| Variable | Default | Description |
|---|---|---|
| `GROQ_API_KEY` | *(required)* | Free from [console.groq.com/keys](https://console.groq.com/keys) |
| `OWNER_NAME` | `Boss` | How JARVIS addresses you |
| `CITY` | `New Delhi` | Default city for weather |
| `WAKE_WORD` | `jarvis` | Voice activation word |
| `VOICE_SPEED` | `172` | TTS words/minute |
| `AI_MODEL` | `llama-3.1-8b-instant` | Groq model |
| `MAX_TOKENS` | `512` | Max response length |
| `AGENT_TOOLS_ENABLED` | `true` | Enable tool calling |
| `RAG_ENABLED` | `true` | Enable document Q&A |

---

## Development

```bash
pip install -e ".[dev]"

# Run tests
pytest

# Lint
ruff check src/ tests/

# Type check
mypy src/jarvis/config.py src/jarvis/utils/
```

---

## Known Limitations

- **Voice input** requires a working microphone and the `speech_recognition` + `pyaudio` packages
- **TTS** depends on system voices (SAPI5 on Windows, NSSpeechSynthesizer on macOS, espeak on Linux)
- **Brightness control** only works on laptops with supported display drivers
- **RAG** requires ~500MB for the embedding model download on first use
- **Groq free tier** has rate limits — heavy use may require a paid plan
- **App discovery** uses `which`/`PATH` — apps not on PATH may not be found
- **No true sandbox** for `run_python` tool — the AST check is heuristic, not a security boundary

---

## License

[MIT License](LICENSE) — free for personal and commercial use.

Originally forked from [JARVIS-v0](https://github.com/talibmakhdum/JARVIS-v0) by talibmakhdum.
