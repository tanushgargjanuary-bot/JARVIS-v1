"""Web search tool — DuckDuckGo."""

from __future__ import annotations

import requests

from jarvis.tools import tool


@tool(
    "web_search",
    "Search the web using DuckDuckGo for current information.",
    {
        "query": {"type": "string", "description": "Search query"},
        "max_results": {"type": "integer", "description": "Number of results (1-5)", "default": 3},
    },
)
def web_search(query: str, max_results: int = 3) -> str:
    """Search DuckDuckGo and return top results."""
    try:
        resp = requests.get(
            "https://api.duckduckgo.com/",
            params={"q": query, "format": "json", "no_html": 1},
            timeout=10,
        )
        data = resp.json()

        results = []
        # Abstract
        if data.get("AbstractText"):
            results.append(f"Summary: {data['AbstractText']}")
        # Related topics
        for topic in data.get("RelatedTopics", [])[:max_results]:
            if isinstance(topic, dict) and "Text" in topic:
                results.append(f"- {topic['Text']}")

        if not results:
            return f"No results found for '{query}'."

        return "\n".join(results)
    except Exception as exc:
        return f"Search error: {exc}"
