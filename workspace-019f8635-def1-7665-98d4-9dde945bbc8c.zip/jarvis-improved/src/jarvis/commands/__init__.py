"""
Command router — parses user input and dispatches to the right handler.

Pattern-matching approach (no NLP dependency). Each command module registers
patterns via the ``register`` function below.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import Callable

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

@dataclass
class Command:
    """A single command binding."""
    pattern: re.Pattern  # compiled regex
    handler: Callable[..., str]
    description: str = ""
    category: str = "general"


# Global registry
_registry: list[Command] = []


def register(
    pattern: str,
    category: str = "general",
    description: str = "",
) -> Callable:
    """Decorator to register a command handler.

    Usage::

        @register(r"^open (?P<name>.+)", category="pc")
        def open_app(name: str) -> str:
            ...
    """
    compiled = re.compile(pattern, re.IGNORECASE)

    def decorator(func: Callable) -> Callable:
        _registry.append(Command(
            pattern=compiled,
            handler=func,
            description=description or func.__doc__ or "",
            category=category,
        ))
        return func

    return decorator


def match_command(text: str) -> tuple[Command, dict[str, str]] | None:
    """Try to match *text* against all registered commands.

    Returns (command, match_groups) or None.
    """
    text = text.strip()
    for cmd in _registry:
        m = cmd.pattern.match(text)
        if m:
            return cmd, m.groupdict()
    return None


def list_commands() -> list[dict[str, str]]:
    """Return a summary of all registered commands."""
    return [
        {"pattern": c.pattern.pattern, "category": c.category, "description": c.description}
        for c in _registry
    ]


# ---------------------------------------------------------------------------
# Import sub-modules so their @register decorators fire
# ---------------------------------------------------------------------------

def _load_commands() -> None:
    """Import all command modules so they self-register."""
    from jarvis.commands import cse, daily, fun, notes, pc_control, web  # noqa: F401


_load_commands()
