"""Theme constants for the JARVIS UI."""

THEME = {
    "bg_primary": "#0d1117",
    "bg_secondary": "#161b22",
    "bg_tertiary": "#21262d",
    "accent": "#58a6ff",
    "accent_hover": "#79b8ff",
    "text_primary": "#e6edf3",
    "text_secondary": "#8b949e",
    "text_muted": "#484f58",
    "border": "#30363d",
    "error": "#f85149",
    "success": "#3fb950",
    "warning": "#d29922",
}
